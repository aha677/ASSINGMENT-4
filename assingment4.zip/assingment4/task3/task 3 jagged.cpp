#include <iostream>
#include <fstream>
using namespace std;

const int MAX_ROWS = 100;

int* jagged[MAX_ROWS];
int rowSizes[MAX_ROWS];
int totalRows = 0;

void writeToFile(const char filename[]) {
    ofstream file(filename);
    if (!file) return;
    file << totalRows << endl;
    for (int i = 0; i < totalRows; i++) {
        file << rowSizes[i] << " ";
        for (int j = 0; j < rowSizes[i]; j++) {
            file << jagged[i][j] << " ";
        }
        file << endl;
    }
    file.close();
}

void inputJaggedArray() {
    cout << "Enter number of rows: ";
    cin >> totalRows;
    for (int i = 0; i < totalRows; i++) {
        cout << "Enter number of elements in row " << i << ": ";
        cin >> rowSizes[i];
        jagged[i] = new int[rowSizes[i]];
        for (int j = 0; j < rowSizes[i]; j++) {
            cout << "Enter element [" << i << "][" << j << "]: ";
            cin >> jagged[i][j];
        }
    }
    writeToFile("jagged_before.txt");
}

void displayJaggedArray() {
    cout << "Jagged Array:\n";
    for (int i = 0; i < totalRows; i++) {
        for (int j = 0; j < rowSizes[i]; j++) {
            cout << jagged[i][j] << " ";
        }
        cout << endl;
    }
}

void growAtFront() {
    int* newRow;
    int newSize;
    cout << "Enter size of new row: ";
    cin >> newSize;
    newRow = new int[newSize];
    cout << "Enter elements:\n";
    for (int i = 0; i < newSize; i++) cin >> newRow[i];
    for (int i = totalRows; i > 0; i--) {
        jagged[i] = jagged[i - 1];
        rowSizes[i] = rowSizes[i - 1];
    }
    jagged[0] = newRow;
    rowSizes[0] = newSize;
    totalRows++;
    writeToFile("jagged_after.txt");
}

void growAtEnd() {
    int size;
    cout << "Enter size of new row: ";
    cin >> size;
    jagged[totalRows] = new int[size];
    cout << "Enter elements:\n";
    for (int i = 0; i < size; i++) cin >> jagged[totalRows][i];
    rowSizes[totalRows] = size;
    totalRows++;
    writeToFile("jagged_after.txt");
}

void growAtPosition() {
    int pos, size;
    cout << "Enter position to insert at (0 to " << totalRows << "): ";
    cin >> pos;
    if (pos < 0 || pos > totalRows) {
        cout << "Invalid position.\n";
        return;
    }
    int* newRow;
    cout << "Enter size of new row: ";
    cin >> size;
    newRow = new int[size];
    cout << "Enter elements:\n";
    for (int i = 0; i < size; i++) cin >> newRow[i];
    for (int i = totalRows; i > pos; i--) {
        jagged[i] = jagged[i - 1];
        rowSizes[i] = rowSizes[i - 1];
    }
    jagged[pos] = newRow;
    rowSizes[pos] = size;
    totalRows++;
    writeToFile("jagged_after.txt");
}

void shrinkFront() {
    if (totalRows == 0) return;
    delete[] jagged[0];
    for (int i = 0; i < totalRows - 1; i++) {
        jagged[i] = jagged[i + 1];
        rowSizes[i] = rowSizes[i + 1];
    }
    totalRows--;
    writeToFile("jagged_after.txt");
}

void shrinkEnd() {
    if (totalRows == 0) return;
    delete[] jagged[totalRows - 1];
    totalRows--;
    writeToFile("jagged_after.txt");
}

void shrinkAtPosition() {
    int pos;
    cout << "Enter position to remove (0 to " << totalRows - 1 << "): ";
    cin >> pos;
    if (pos < 0 || pos >= totalRows) {
        cout << "Invalid position.\n";
        return;
    }
    delete[] jagged[pos];
    for (int i = pos; i < totalRows - 1; i++) {
        jagged[i] = jagged[i + 1];
        rowSizes[i] = rowSizes[i + 1];
    }
    totalRows--;
    writeToFile("jagged_after.txt");
}

void showMenu() {
    cout << "\n--- Jagged Array Menu ---\n";
    cout << "1. Grow at Front\n";
    cout << "2. Grow at End\n";
    cout << "3. Grow at Position\n";
    cout << "4. Shrink Front\n";
    cout << "5. Shrink End\n";
    cout << "6. Shrink at Position\n";
    cout << "7. Display Array\n";
    cout << "0. Exit\n";
}

int main() {
    inputJaggedArray();
    int choice;
    do {
        showMenu();
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
        case 1: growAtFront(); break;
        case 2: growAtEnd(); break;
        case 3: growAtPosition(); break;
        case 4: shrinkFront(); break;
        case 5: shrinkEnd(); break;
        case 6: shrinkAtPosition(); break;
        case 7: displayJaggedArray(); break;
        case 0: cout << "Exiting...\n"; break;
        default: cout << "Invalid option!\n";
        }
    } while (choice != 0);
    for (int i = 0; i < totalRows; i++)
        delete[] jagged[i];
    return 0;
}
