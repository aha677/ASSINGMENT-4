#include <iostream>    
#include <fstream>     
using namespace std;

const int MAX_ROWS = 100;  
const int MAX_COLS = 100;  

void saveToFile(const char filename[], int arr[][MAX_COLS], int rows, int cols) {
    ofstream file(filename);
    for (int i = 0; i < rows; i++) {        
        for (int j = 0; j < cols; j++) {      
            file << arr[i][j] << " ";         
        }
        file << endl;                         
    }
    file.close();   
}

void addRowFront(int arr[][MAX_COLS], int& rows, int cols, int newRow[]) {
    saveToFile("original.txt", arr, rows, cols);
    for (int i = rows; i > 0; i--) {           
        for (int j = 0; j < cols; j++) {
            arr[i][j] = arr[i - 1][j];           
        }
    }
    for (int j = 0; j < cols; j++) {
        arr[0][j] = newRow[j];                    
    }
    rows++;                                      
    saveToFile("updated.txt", arr, rows, cols);   
}

void addRowEnd(int arr[][MAX_COLS], int& rows, int cols, int newRow[]) {
    saveToFile("original.txt", arr, rows, cols);
    for (int j = 0; j < cols; j++) {
        arr[rows][j] = newRow[j];  
    }
    rows++;                         
    saveToFile("updated.txt", arr, rows, cols);
}

void addRowAtPosition(int arr[][MAX_COLS], int& rows, int cols, int position, int newRow[]) {
    if (position < 0 || position > rows) {   
        cout << "Invalid position!\n";
        return;
    }
    saveToFile("original.txt", arr, rows, cols);
    for (int i = rows; i > position; i--) {  
        for (int j = 0; j < cols; j++) {
            arr[i][j] = arr[i - 1][j];
        }
    }
    for (int j = 0; j < cols; j++) {
        arr[position][j] = newRow[j];   
    }
    rows++;                          
    saveToFile("updated.txt", arr, rows, cols);
}

void removeRowFront(int arr[][MAX_COLS], int& rows, int cols) {
    if (rows <= 0) return;        
    saveToFile("original.txt", arr, rows, cols);
    for (int i = 0; i < rows - 1; i++) { 
        for (int j = 0; j < cols; j++) {
            arr[i][j] = arr[i + 1][j];
        }
    }
    rows--;     
    saveToFile("updated.txt", arr, rows, cols);
}

void removeRowEnd(int arr[][MAX_COLS], int& rows, int cols) {
    if (rows <= 0) return;
    saveToFile("original.txt", arr, rows, cols);
    rows--; 
    saveToFile("updated.txt", arr, rows, cols);
}

void removeRowAtPosition(int arr[][MAX_COLS], int& rows, int cols, int position) {
    if (position < 0 || position >= rows) {
        cout << "Invalid position!\n";
        return;
    }
    saveToFile("original.txt", arr, rows, cols);
    for (int i = position; i < rows - 1; i++) {   
        for (int j = 0; j < cols; j++) {
            arr[i][j] = arr[i + 1][j];
        }
    }
    rows--; 
    saveToFile("updated.txt", arr, rows, cols);
}

void printArray(int arr[][MAX_COLS], int rows, int cols) {
    cout << "\nArray:\n";
    for (int i = 0; i < rows; i++) {      
        for (int j = 0; j < cols; j++) {
            cout << arr[i][j] << "\t";     
        }
        cout << endl;
    }
}

int main() {
    int arr[MAX_ROWS][MAX_COLS];   
    int rows, cols;

    cout << "Enter number of rows and columns: ";
    cin >> rows >> cols;  

    cout << "Enter elements of the array:\n";
    for (int i = 0; i < rows; i++) {       
        for (int j = 0; j < cols; j++) {
            cin >> arr[i][j];
        }
    }

    int choice;
    do {
        cout << "\nMenu:\n";
        cout << "1. Grow from front\n2. Grow from end\n3. Grow at position\n";
        cout << "4. Shrink from front\n5. Shrink from end\n6. Shrink at position\n0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        int newRow[MAX_COLS], pos;
        switch (choice) {
        case 1:
            cout << "Enter values for new row:\n";
            for (int j = 0; j < cols; j++) cin >> newRow[j];
            addRowFront(arr, rows, cols, newRow);
            break;
        case 2:
            cout << "Enter values for new row:\n";
            for (int j = 0; j < cols; j++) cin >> newRow[j];
            addRowEnd(arr, rows, cols, newRow);
            break;
        case 3:
            cout << "Enter position to insert new row: ";
            cin >> pos;
            cout << "Enter values for new row:\n";
            for (int j = 0; j < cols; j++) cin >> newRow[j];
            addRowAtPosition(arr, rows, cols, pos, newRow);
            break;
        case 4:
            removeRowFront(arr, rows, cols);
            break;
        case 5:
            removeRowEnd(arr, rows, cols);
            break;
        case 6:
            cout << "Enter position to remove row: ";
            cin >> pos;
            removeRowAtPosition(arr, rows, cols, pos);
            break;
        case 0:
            cout << "Exiting...\n";   
            break;
        default:
            cout << "Invalid option!\n"; 
        }

        printArray(arr, rows, cols); 

    } while (choice != 0);  

    return 0;
}
