#include <iostream>
using namespace std;

const int sizz = 100;

// 1. Grow from front
void enterValueAtFront(int arr[], int& s, int startValue) {
    for (int i = s; i > 0; i--) {
        arr[i] = arr[i - 1];
    }
    arr[0] = startValue;
    s++;

    cout << "\nArray after inserting at front:\n";
    for (int i = 0; i < s; i++) {
        cout << "\t" << arr[i];
    }
    cout << "\nSize of the array is: " << s << endl;
}

// 2. Grow from end
void enterValueAtEnd(int arr[], int& s, int valueend) {
    arr[s] = valueend;
    s++;

    cout << "\nArray after inserting at end:\n";
    for (int i = 0; i < s; i++) {
        cout << "\t" << arr[i];
    }
    cout << "\nSize of the array is: " << s << endl;
}

// 3. Grow at specific position
void growModeAtPosition(int arr[], int& s, int positionToEnterValue, int valuePosition) {
    if (positionToEnterValue < 0 || positionToEnterValue > s) {
        cout << "Invalid position!\n";
        return;
    }

    for (int i = s; i > positionToEnterValue; i--) {
        arr[i] = arr[i - 1];
    }
    arr[positionToEnterValue] = valuePosition;
    s++;

    cout << "\nArray after inserting at position " << positionToEnterValue << ":\n";
    for (int i = 0; i < s; i++) {
        cout << "\t" << arr[i];
    }
    cout << "\nSize of the array is: " << s << endl;
}

// 4. Shrink from front
void shrinkValueFront(int arr[], int& s) {
    for (int i = 0; i < s - 1; i++) {
        arr[i] = arr[i + 1];
    }
    s--;

    cout << "\nArray after removing from front:\n";
    for (int i = 0; i < s; i++) {
        cout << "\t" << arr[i];
    }
    cout << "\nSize of the array is: " << s << endl;
}

// 5. Shrink from end
void shrinkValueAtEndPoint(int arr[], int& s) {
    s--;

    cout << "\nArray after removing from end:\n";
    for (int i = 0; i < s; i++) {
        cout << "\t" << arr[i];
    }
    cout << "\nSize of the array is: " << s << endl;
}

// 6. Shrink from specific position
void shrinkFromPosition(int arr[], int& s, int positionToRemove) {
    if (positionToRemove < 0 || positionToRemove >= s) {
        cout << "Invalid position!\n";
        return;
    }

    for (int i = positionToRemove; i < s - 1; i++) {
        arr[i] = arr[i + 1];
    }
    s--;

    cout << "\nArray after removing value at position " << positionToRemove << ":\n";
    for (int i = 0; i < s; i++) {
        cout << "\t" << arr[i];
    }
    cout << "\nSize of the array is: " << s << endl;
}

int main() {
    int s;
    int arr[sizz];

    cout << "Enter the size of the array: ";
    cin >> s;

    for (int i = 0; i < s; i++) {
        cout << "Enter the value at index " << i + 1 << ": ";
        cin >> arr[i];
    }

    int startValue;
    cout << "\nEnter value to insert at front (index 0): ";
    cin >> startValue;
    enterValueAtFront(arr, s, startValue);

    int valueend;
    cout << "\nEnter value to insert at end: ";
    cin >> valueend;
    enterValueAtEnd(arr, s, valueend);

    int positionToEnterValue;
    cout << "\nEnter position to insert value: ";
    cin >> positionToEnterValue;

    int valuePosition;
    cout << "Enter value to insert at position " << positionToEnterValue << ": ";
    cin >> valuePosition;
    growModeAtPosition(arr, s, positionToEnterValue, valuePosition);

    shrinkValueFront(arr, s);
    shrinkValueAtEndPoint(arr, s);

    int positionToRemove;
    cout << "\nEnter position to remove value: ";
    cin >> positionToRemove;
    shrinkFromPosition(arr, s, positionToRemove);

    return 0;
}
